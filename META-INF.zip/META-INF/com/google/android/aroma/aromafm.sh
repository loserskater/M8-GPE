#!/sbin/sh
echo "ziplocation=${UPDATE_PACKAGE}" > /tmp/aroma/aromafm.prop